-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.6.31-0ubuntu0.15.10.1 - (Ubuntu)
-- OS do Servidor:               debian-linux-gnu
-- HeidiSQL Versão:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para elu
CREATE DATABASE IF NOT EXISTS `elu` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `elu`;


-- Copiando estrutura para tabela elu.answer
CREATE TABLE IF NOT EXISTS `answer` (
  `id` bigint(20) NOT NULL,
  `score` int(11) NOT NULL,
  `accepted` int(1) NOT NULL,
  `downVoteCount` int(11) NOT NULL,
  `lastActivityDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `body` text NOT NULL,
  `questionId` bigint(20) DEFAULT NULL,
  `upVoteCount` int(11) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_answer_user` (`userId`),
  KEY `fk_answer_question` (`questionId`),
  CONSTRAINT `fk_answer_question` FOREIGN KEY (`questionId`) REFERENCES `question` (`id`),
  CONSTRAINT `fk_answer_user` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.answer_comment
CREATE TABLE IF NOT EXISTS `answer_comment` (
  `id` bigint(20) NOT NULL,
  `score` int(11) NOT NULL,
  `answerId` bigint(20) NOT NULL,
  `edited` int(1) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `body` text NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_answer_comment_answer` (`answerId`),
  KEY `fk_answer_comment_user` (`userId`),
  CONSTRAINT `fk_answer_comment_answer` FOREIGN KEY (`answerId`) REFERENCES `answer` (`id`),
  CONSTRAINT `fk_answer_comment_user` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.question
CREATE TABLE IF NOT EXISTS `question` (
  `id` bigint(20) NOT NULL,
  `lastActivityDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `answerCount` int(11) NOT NULL,
  `title` text NOT NULL,
  `body` text NOT NULL,
  `score` int(11) NOT NULL,
  `downVoteCount` int(11) NOT NULL,
  `viewCount` int(11) NOT NULL,
  `answered` int(1) NOT NULL,
  `upVoteCount` int(11) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_question_user` (`userId`),
  CONSTRAINT `fk_question_user` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.question_comment
CREATE TABLE IF NOT EXISTS `question_comment` (
  `id` bigint(20) NOT NULL,
  `score` int(11) NOT NULL,
  `questionId` bigint(20) NOT NULL,
  `edited` int(1) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `body` text NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_question_comment_user` (`userId`),
  KEY `fk_question_comment_question` (`questionId`),
  CONSTRAINT `fk_question_comment_question` FOREIGN KEY (`questionId`) REFERENCES `question` (`id`),
  CONSTRAINT `fk_question_comment_user` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.question_tag
CREATE TABLE IF NOT EXISTS `question_tag` (
  `questionId` bigint(20) NOT NULL,
  `tagId` bigint(20) NOT NULL,
  PRIMARY KEY (`questionId`,`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.tag
CREATE TABLE IF NOT EXISTS `tag` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela elu.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL,
  `reputation` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `ex` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Exportação de dados foi desmarcado.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
